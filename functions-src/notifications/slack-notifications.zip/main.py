import base64
import functions_framework
import os

import requests

def send_slack_message(token, channel_id, message):
    url = 'https://slack.com/api/chat.postMessage'
    headers = {'Authorization': 'Bearer ' + token}
    data = {'channel': channel_id, 'text': message}

    response = requests.post(url, headers=headers, data=data)

    if response.status_code == 200 and response.json()["ok"]:
        print("Message sent successfully!")
    else:
        print(f"Failed to send message. Error: {response.text}")



# Triggered from a message on a Cloud Pub/Sub topic.
@functions_framework.cloud_event
def hello_pubsub(cloud_event):
    slack_token = os.getenv('SLACK_API_TOKEN')
    channel_id = 'deployment-notifications'

    try:
        # Print out the data from Pub/Sub, to prove that it worked
        print(cloud_event)

        data = cloud_event.data["message"]["attributes"]

        _type = data["ResourceType"]
        action = data["Action"]

        if _type != "Rollout" or action == "Start":
            return

        state = "finished successfully ✅"
        if action != "Succeed":
            state = "failed :x:"

        message = f"""
*Deployment {state}*
    • Release: {data['ReleaseId']}
    • Rollout: {data['RolloutId']}
    • Target: {data['TargetId']}
    """.strip()
    except Exception as e:
        message = f'{type(e).__name__}: {e}'

    send_slack_message(slack_token, channel_id, message)