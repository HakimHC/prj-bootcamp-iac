import functions_framework
from google.cloud import run_v2
from google.auth import default
from markupsafe import escape


@functions_framework.http
def hello_http(request):
    project_id = 'jalal2024'
    region = 'europe-west1'

    credentials, _ = default()

    request_json = request.get_json(silent=True)
    if request_json and 'service_name' in request_json:
        service_name = escape(request_json['service_name'])
    else:
        return 'No service name provided', 400

    client = run_v2.ServicesClient(credentials=credentials)

    service_resource_name = f"projects/{project_id}/locations/{region}/services/{service_name}"     

    try:
        service = client.get_service(name=service_resource_name)
        service_url = service.uri
        return {"service_url": service_url}
    except Exception as e:
        return f"Error retrieving service: {str(e)}", 500